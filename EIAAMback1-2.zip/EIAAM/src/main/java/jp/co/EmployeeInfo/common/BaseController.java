package jp.co.EmployeeInfo.common;

public class BaseController {

}
